#!/bin/bash

SCRIPT_NAME=$(basename "$0")
PID=$$

echo "[$PID] $(date '+%Y-%m-%d %H:%M:%S') Скрипт запущен" >> "$report_template_task.log"

if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
echo "я бригадир, сам не работаю"
exit 1
fi

RANDOM_SECONDS=$(( RANDOM % 1771 + 30))

sleep $RANDOM_SECONDS

MINUTES=$(( (RANDOM_SECONDS + 59) / 60 ))

echo "[$PID] $(date '+%Y-%m-%d %H:%M:%S') Скрипт завершился, работал $MINUTES минут" >> "report_template_task.log"

